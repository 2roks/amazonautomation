import fs from 'fs';

const files = ['src/App.tsx', 'src/components/BookingModal.tsx', 'src/components/Navbar.tsx'];

for (const file of files) {
  if (!fs.existsSync(file)) continue;
  let content = fs.readFileSync(file, 'utf8');
  
  // Replace extremely rounded corners with sharper enterprise variants
  content = content.replace(/rounded-3xl/g, 'rounded-xl');
  content = content.replace(/rounded-2xl/g, 'rounded-xl');
  content = content.replace(/rounded-full/g, 'rounded-md'); // For badges
  
  fs.writeFileSync(file, content);
}
console.log('Done sharpifying corners.');
