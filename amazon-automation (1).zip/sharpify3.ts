import fs from 'fs';

let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(/rounded-xl/g, 'rounded-md');
content = content.replace(/shadow-2xl/g, 'shadow-xl');
// Change abstract blurs that look too Web3/bubbly
content = content.replace(/blur-3xl/g, 'blur-2xl');

fs.writeFileSync('src/App.tsx', content);

let modal = fs.readFileSync('src/components/BookingModal.tsx', 'utf8');
modal = modal.replace(/rounded-xl/g, 'rounded-md');
fs.writeFileSync('src/components/BookingModal.tsx', modal);

console.log("Sharpened");
