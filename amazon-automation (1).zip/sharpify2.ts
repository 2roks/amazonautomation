import fs from 'fs';

const files = ['src/App.tsx', 'src/components/BookingModal.tsx', 'src/components/Navbar.tsx'];

for (const file of files) {
  if (!fs.existsSync(file)) continue;
  let content = fs.readFileSync(file, 'utf8');
  
  // Replace rounded-xl on buttons and inputs with rounded-sm or rounded for a sharper edge
  content = content.replace(/rounded-xl/g, 'rounded-sm');
  
  fs.writeFileSync(file, content);
}
console.log('Done sharpifying step 2.');
