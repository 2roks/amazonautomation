import React, { useState, useEffect } from 'react';
import { useAntiInspect } from './hooks/useAntiInspect';
import { 
  Check, 
  Store, 
  MapPin,
  AlertTriangle, 
  Clock, 
  ShieldCheck, 
  Users, 
  TrendingUp, 
  ChevronDown, 
  Maximize, 
  Phone, 
  Layers, 
  Sparkles, 
  Award, 
  ArrowRight,
  BookOpen,
  DollarSign,
  Snowflake,
  Ruler,
  UserX,
  HeartHandshake,
  Coins,
  Footprints,
  FileBadge,
  DraftingCompass,
  Boxes,
  Headphones,
  Truck
} from 'lucide-react';
import Navbar from './components/Navbar';
import BookingModal from './components/BookingModal';
import Logo from './components/Logo';
import FaqSection from './components/FaqSection';
import Footer from './components/Footer';
import RevenueSection from './components/RevenueSection';

// Live Notifications of Pre-Approvals for Social Proof Urgency
const SIMULATED_ALERTS = [
  { message: "Boutique Pharmacy in North End, Boston (02113) pre-approved for Q3 Amazon Route Mapping.", time: "1 min ago" },
  { message: "Local Specialty Store in Dorchester, MA (02124) secured $2,250/mo Hub payout allotment.", time: "4 mins ago" },
  { message: "Convenience Operator on Newbury St, Back Bay (02116) activated full-service delivery routing.", time: "12 mins ago" },
  { message: "Gas & Convenience franchise in Quincy / South Shore (02169) completed site validation.", time: "18 mins ago" },
  { message: "Boutique Retail front in Brookline, MA (02446) secured high-priority courier matching.", time: "25 mins ago" }
];

export default function App() {
  useAntiInspect();

  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [initialStoreType, setInitialStoreType] = useState('convenience');
  const [initialLocations, setInitialLocations] = useState(1);
  
  // Real-time notification rotater
  const [currentAlertIdx, setCurrentAlertIdx] = useState(0);
  const [showAlert, setShowAlert] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setShowAlert(false);
      setTimeout(() => {
        setCurrentAlertIdx((prev) => (prev + 1) % SIMULATED_ALERTS.length);
        setShowAlert(true);
      }, 500); // fade out and in
    }, 7000);
    return () => clearInterval(interval);
  }, []);

  const handleOpenBooking = (storeType: string = 'convenience', locations: number = 1) => {
    setInitialStoreType(storeType);
    setInitialLocations(locations);
    setIsBookingOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50/40 selection:bg-amber-500/20 selection:text-amazon-ink overflow-x-hidden">
      
      {/* Navbar Component */}
      <Navbar onOpenBooking={() => handleOpenBooking()} />

      {/* 1. HERO SECTION */}
      <section className="relative pt-12 pb-16 md:py-28 overflow-hidden bg-white">
        {/* Modern subtle background glow mapping for Whop-style UX */}
        <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-amber-500/5 rounded-md filter blur-2xl pointer-events-none" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#e2e8f0_1px,transparent_1px),linear-gradient(to_bottom,#e2e8f0_1px,transparent_1px)] bg-[size:3rem_3rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-35" />

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-7 space-y-6 md:space-y-8">
              
              {/* Audience Targeting Badge */}
              <div className="space-y-3.5">
                <span className="text-[11px] uppercase font-mono tracking-widest font-extrabold text-amber-500 bg-amber-50 border border-amber-200 px-3.5 py-1.5 rounded-md inline-block">
                  Boston Storefront Delivery Partnership
                </span>
                <div className="text-xs md:text-sm text-slate-500 font-medium">
                  Convenience stores, independent pharmacies, and specialty shops in Boston and surrounding areas.
                </div>
              </div>

              {/* Headline */}
              <h1 className="font-display text-4xl sm:text-5xl lg:text-5xl font-extrabold tracking-tight text-slate-900 leading-[1.05] md:text-5xl lg:text-6xl">
                Add <span className="text-amber-500 underline decoration-amber-500/40 decoration-wavy sm:inline">Passive Income</span> to Your Existing Business via Amazon Hub
              </h1>

              {/* Sub-Headline */}
              <p className="text-slate-600 text-base sm:text-lg max-w-2xl leading-relaxed">
                We handle setup, logistics, and route coordination while you receive consistent weekly payouts.
              </p>

              {/* Multi-CTA */}
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
                <button
                  id="hero-cta-btn"
                  onClick={() => handleOpenBooking()}
                  className="rounded-md bg-amazon-gold hover:bg-amazon-gold-hover active:scale-[0.99] text-amazon-ink font-extrabold py-4 px-8 text-sm sm:text-base tracking-wide transition shadow-lg shadow-amber-500/10 flex items-center justify-center gap-2 cursor-pointer group"
                >
                  Check Zip Code Eligibility
                  <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition" />
                </button>

                <a 
                  href="#revenue-section" 
                  className="rounded-md border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 font-bold py-4 px-7 text-sm sm:text-base transition flex items-center justify-center gap-2"
                >
                  <TrendingUp className="h-4.5 w-4.5 text-amazon-gold" />
                  See Revenue Breakdown
                </a>
              </div>

              {/* Core Metrics */}
              <div className="grid grid-cols-3 gap-2 sm:gap-4 pt-6 md:pt-10 border-t border-slate-100 max-w-lg">
                <div>
                  <div className="font-mono text-xl sm:text-2xl font-black text-slate-900">
                    $2.50<span className="text-amazon-gold text-base sm:text-lg">+</span>
                  </div>
                  <p className="text-[9px] sm:text-[11px] text-slate-500 uppercase tracking-widest font-bold mt-0.5">Payout Per Pkg</p>
                </div>
                <div>
                  <div className="font-mono text-xl sm:text-2xl font-black text-slate-900">
                    $0
                  </div>
                  <p className="text-[9px] sm:text-[11px] text-slate-500 uppercase tracking-widest font-bold mt-0.5">Upfront Cost</p>
                </div>
                <div>
                  <div className="font-mono text-xl sm:text-2xl font-black text-[#0f172a]">
                    100%
                  </div>
                  <p className="text-[9px] sm:text-[11px] text-slate-500 uppercase tracking-widest font-bold mt-0.5">Risk-Free</p>
                </div>
              </div>
            </div>

            {/* Right Graphic Column with Generated Image */}
            <div className="lg:col-span-5 relative w-full flex justify-center lg:justify-end">
              <div className="relative w-full max-w-[460px] md:max-w-[500px] aspect-[4/3] rounded-md overflow-hidden shadow-xl border-4 border-white ring-8 ring-slate-100/50 group">
                <img 
                  src="/src/assets/images/oim_retail_logistics_1779590887168.png" 
                  alt="Amazon Hub partner order and inventory management setup"
                  className="w-full h-full object-cover rounded-md group-hover:scale-105 transition-all duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />

                {/* Subtile Powered By Amazon Watermark overlay */}
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-full shadow-sm border border-white/20 flex items-center gap-1.5 transition-opacity duration-300 pointer-events-none">
                  <span className="text-[9px] font-bold tracking-widest text-slate-500 uppercase">Powered by</span>
                  <img 
                    src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" 
                    alt="Amazon" 
                    className="h-2.5 sm:h-3 object-contain mt-0.5" 
                  />
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. THE PROBLEM SECTION */}
      <section id="problem-section" className="py-16 md:py-24 bg-slate-50 border-t border-b border-slate-100 scroll-mt-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-12">
            <span className="text-xs font-bold text-amazon-gold uppercase tracking-widest bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200">
              Commercial Efficiency
            </span>
            <h2 className="font-display text-3xl font-extrabold tracking-tight text-slate-900 leading-tight">
              Optimize Every Square Foot of Lease Space
            </h2>
            <p className="text-slate-500 text-sm leading-relaxed">
              Rising retail rents require optimizing storefront square footage. An underutilized back room, storage alcove, or unused counter end represents missed weekly income.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            
            {/* Pain Point Card 1 */}
            <div className="rounded-md bg-white border border-slate-150 p-6 md:p-8 space-y-4 shadow-sm hover:shadow-md transition">
              <div className="flex h-12 w-12 items-center justify-center rounded-md bg-red-50 text-red-600 border border-red-100">
                <Snowflake className="h-6 w-6" />
              </div>
              <h3 className="font-display font-bold text-lg text-slate-900">
                Seasonal Revenue Dips
              </h3>
              <p className="text-xs md:text-sm text-[#ef4444] font-medium leading-relaxed">
                Foot traffic is highly seasonal and weather-dependent. A predictable logistics payout flatlines these seasonal sales drops.
              </p>
            </div>

            {/* Pain Point Card 2 */}
            <div className="rounded-md bg-white border border-slate-150 p-6 md:p-8 space-y-4 shadow-sm hover:shadow-md transition">
              <div className="flex h-12 w-12 items-center justify-center rounded-md bg-red-50 text-red-600 border border-red-100">
                <Ruler className="h-6 w-6 animate-pulse" />
              </div>
              <h3 className="font-display font-bold text-lg text-slate-900">
                Unproductive Square Footage
              </h3>
              <p className="text-xs md:text-sm text-slate-500 leading-relaxed">
                An empty corner, dead shelf space, or unused back wall costs you money. Converting it into a parcel holding station puts it to work immediately.
              </p>
            </div>

            {/* Pain Point Card 3 */}
            <div className="rounded-md bg-white border border-slate-150 p-6 md:p-8 space-y-4 shadow-sm hover:shadow-md transition">
              <div className="flex h-12 w-12 items-center justify-center rounded-md bg-red-50 text-red-600 border border-red-100">
                <UserX className="h-6 w-6" />
              </div>
              <h3 className="font-display font-bold text-lg text-slate-900">
                No Staff Distraction
              </h3>
              <p className="text-xs md:text-sm text-slate-500 leading-relaxed">
                Your staff is already occupied. This program does not add package registration and returns work to your cashier register desks.
              </p>
            </div>

          </div>

          {/* Action box inside problems */}
          <div className="mt-8 bg-amazon-ink rounded-md p-6 md:p-8 text-white flex flex-col md:flex-row items-center justify-between gap-6 border border-amazon-ink-light">
            <div className="space-y-1.5 md:flex-1">
              <h4 className="font-display font-bold text-lg text-amazon-gold tracking-tight">
                Capitalize on Local Delivery Density
              </h4>
              <p className="text-xs text-slate-300">
                Amazon needs secure storefront hubs to host daily route drops. We manage the setup and approval so you can profit from this local delivery volume hands-free.
              </p>
            </div>
            <button 
              onClick={() => handleOpenBooking()}
              className="w-full md:w-auto shrink-0 rounded-md bg-white text-amazon-ink font-bold px-6 py-3 text-xs md:text-sm hover:bg-slate-100 active:scale-[0.98] transition cursor-pointer"
            >
              Verify My Hub Availability
            </button>
          </div>
        </div>
      </section>

      {/* 3. SOLUTION & CORE VALUE PROPOSITION */}
      <section id="how-it-works" className="py-16 md:py-24 bg-white scroll-mt-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
            
            {/* Left summary bullet */}
            <div className="lg:col-span-5 space-y-6">
              <span className="inline-flex rounded-md bg-amber-50 border border-amber-200 px-2.5 py-1 text-xs font-bold text-amazon-gold uppercase tracking-widest">
                Full Onboarding Service
              </span>
              <h2 className="font-display text-3xl font-extrabold text-slate-900 tracking-tight">
                Complete Setup & Operations Management
              </h2>
              <p className="text-slate-600 text-sm leading-relaxed">
                We handle the administrative hurdles. Navigating corporate applications, local route compliance, and scanner tech sync should never take focus away from your day-to-day customers.
              </p>
              
              <div className="rounded-md border border-slate-100 bg-slate-50 p-5 mt-4 space-y-4">
                <h4 className="font-display font-bold text-sm text-slate-900 uppercase tracking-wide">Risk-Free Integration</h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  We absorb all upfront setup and compliance costs to establish a completely friction-free business income expansion.
                </p>
                <div className="flex gap-4">
                  <div className="flex-1 bg-white p-3 rounded-lg border border-slate-200">
                    <span className="block text-[10px] uppercase font-bold text-amazon-gold font-sans">Upfront Cost</span>
                    <strong className="text-lg font-mono text-slate-900">$0 Setup</strong>
                  </div>
                  <div className="flex-1 bg-white p-3 rounded-lg border border-slate-200">
                    <span className="block text-[10px] uppercase font-bold text-slate-400 font-sans">Commitment</span>
                    <strong className="text-lg font-mono text-slate-700">100% Risk-Free</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Right bullet list items */}
            <div className="lg:col-span-7 space-y-4.5">
              
              {/* Feature Benefit 1 */}
              <div className="flex items-start gap-4 rounded-md bg-slate-50 p-5 md:p-6 border border-slate-100 hover:border-amazon-gold/25 hover:shadow-sm transition-all duration-200">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-100">
                  <HeartHandshake className="h-5.5 w-5.5" />
                </div>
                <div>
                  <h4 className="font-display font-bold text-base text-slate-900 mb-1">
                    Zero Operational Disruption
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Local pickups are fully automated. Your retail cashier stays focused on standard in-person customer service.
                  </p>
                </div>
              </div>

              {/* Feature Benefit 2 */}
              <div className="flex items-start gap-4 rounded-md bg-slate-50 p-5 md:p-6 border border-slate-100 hover:border-amazon-gold/25 hover:shadow-sm transition-all duration-200">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-100">
                  <Coins className="h-5.5 w-5.5" />
                </div>
                <div>
                  <h4 className="font-display font-bold text-base text-slate-900 mb-1">
                    No Added Payroll
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    The package service fits directly into your existing retail hours. You expand earnings without ever hiring new help.
                  </p>
                </div>
              </div>

              {/* Feature Benefit 3 */}
              <div className="flex items-start gap-4 rounded-md bg-slate-50 p-5 md:p-6 border border-slate-100 hover:border-amazon-gold/25 hover:shadow-sm transition-all duration-200">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-100">
                  <Footprints className="h-5.5 w-5.5" />
                </div>
                <div>
                  <h4 className="font-display font-bold text-base text-slate-900 mb-1">
                    Free Foot Traffic
                  </h4>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Every pickup guest is a neighborhood local. Studies show 12% to 18% of delivery visitors buy snacks or groceries during pickups.
                  </p>
                </div>
              </div>

            </div>

          </div>

        </div>
      </section>

      {/* 4. WHY RETAIL STOREFRONTS ARE IDEAL */}
      <section className="py-16 md:py-24 bg-slate-900 text-white relative overflow-hidden">
        {/* Abstract blur backdrop */}
        <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-md blur-2xl" />
        <div className="absolute bottom-1/2 right-1/4 w-80 h-80 bg-amber-500/10 rounded-md blur-2xl" />

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative">
          
          <div className="max-w-3xl mx-auto text-center space-y-3 mb-10">
            <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-md border border-emerald-500/20">
              Retail Synergy
            </span>
            <h2 className="font-display text-3xl font-extrabold tracking-tight">
              Why Local Storefronts are Ideal Hosts
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Amazon uses neighborhood retailers as local parcel pickup spots because physical shops offer steady open hours and convenient, secure street-level access.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            
            {/* Ideal Point 1 */}
            <div className="bg-slate-800/40 rounded-md p-6 border border-slate-800 space-y-3">
              <span className="font-mono text-emerald-400 text-xs font-bold tracking-wider">01 // TRUST</span>
              <h4 className="font-display font-bold text-base text-white">Established Presence</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                You are registered and established in the community, making your storefront a safe, familiar stop for neighbor pickups.
              </p>
            </div>

            {/* Ideal Point 2 */}
            <div className="bg-slate-800/40 rounded-md p-6 border border-slate-800 space-y-3">
              <span className="font-mono text-emerald-400 text-xs font-bold tracking-wider">02 // HOURS</span>
              <h4 className="font-display font-bold text-base text-white">Active Core Hours</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Your shop is open throughout the daytime and evening, ensuring seamless courier Drop-offs and buyer collections.
              </p>
            </div>

            {/* Ideal Point 3 */}
            <div className="bg-slate-800/40 rounded-md p-6 border border-slate-800 space-y-3">
              <span className="font-mono text-emerald-400 text-xs font-bold tracking-wider">03 // INVENTORY</span>
              <h4 className="font-display font-bold text-base text-white">No Inventory Costs</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Zero wholesale capital risks. All items arrive pre-labeled and insured. Your storefront simply acts as a temporary holding node.
              </p>
            </div>

            {/* Ideal Point 4 */}
            <div className="bg-slate-800/40 rounded-md p-6 border border-slate-800 space-y-3">
              <span className="font-mono text-emerald-400 text-xs font-bold tracking-wider">04 // SCALE</span>
              <h4 className="font-display font-bold text-base text-white">Multi-Location Clean Rollout</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                We organize parallel rollout deployments across your entire retail chain, delivering unified weekly earnings reporting directly.
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* 5. WHAT WE MANAGE SECTION (THE DEEP TRUST GRID) */}
      <section className="py-16 md:py-24 bg-white scroll-mt-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-widest bg-emerald-50 px-2.5 py-1 rounded-md">
              Full Logistics Management
            </span>
            <h2 className="font-display text-3xl font-extrabold text-slate-900 tracking-tight">
              We Manage the Operations. You Collect Weekly Deposits.
            </h2>
            <p className="text-slate-500 text-sm leading-relaxed">
              We take care of the heavy administrative and setup tasks. Here is exactly how we divide the daily responsibilities:
            </p>
          </div>

          {/* Division of Labor Compare Card grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12">
            
            {/* The Agency Handled Side */}
            <div className="rounded-md border border-amazon-gold/25 bg-amber-50/10 p-6 md:p-8 space-y-6 relative">
              <div className="absolute top-4 right-4 rounded-md bg-amber-100 px-3 py-1 text-xs font-bold text-amazon-ink border border-amber-200">
                Managed by Our Agency
              </div>
              <h3 className="font-display font-extrabold text-xl text-amazon-ink">
                What we handle for you:
              </h3>
              
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <div className="mt-1 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-md bg-amazon-gold text-white shadow-sm shadow-amber-500/10">
                    <Check className="h-3 w-3" />
                  </div>
                  <span className="text-xs md:text-sm text-slate-700">
                    <strong>Corporate applications:</strong> We route and secure the compliance green light for your physical storefront site.
                  </span>
                </li>

                <li className="flex items-start gap-3">
                  <div className="mt-1 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-md bg-amazon-gold text-white shadow-sm shadow-amber-500/10">
                    <Check className="h-3 w-3" />
                  </div>
                  <span className="text-xs md:text-sm text-slate-700">
                    <strong>Carrier dispatch:</strong> We coordinate directly with regional delivery managers to keep package routes steady.
                  </span>
                </li>

                <li className="flex items-start gap-3">
                  <div className="mt-1 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-md bg-amazon-gold text-white shadow-sm shadow-amber-500/10">
                    <Check className="h-3 w-3" />
                  </div>
                  <span className="text-xs md:text-sm text-slate-700">
                    <strong>Scanner integration:</strong> We deploy and monitor scanner IT devices to ensure full corporate sync.
                  </span>
                </li>

                <li className="flex items-start gap-3">
                  <div className="mt-1 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-md bg-amazon-gold text-white shadow-sm shadow-amber-500/10">
                    <Check className="h-3 w-3" />
                  </div>
                  <span className="text-xs md:text-sm text-slate-700">
                    <strong>Customer service:</strong> We resolve parcel claim issues, matching delays, and recipient verification requests.
                  </span>
                </li>

                <li className="flex items-start gap-3">
                  <div className="mt-1 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-md bg-amazon-gold text-white shadow-sm shadow-amber-500/10">
                    <Check className="h-3 w-3" />
                  </div>
                  <span className="text-xs md:text-sm text-slate-700">
                    <strong>Reporting audits:</strong> We review system tracking logs daily to optimize and verify your weekly earnings.
                  </span>
                </li>
              </ul>
            </div>

            {/* The Store Owner Side (EASY!) */}
            <div className="rounded-md border border-slate-150 bg-slate-50 p-6 md:p-8 space-y-6 relative flex flex-col justify-between">
              <div>
                <div className="absolute top-4 right-4 rounded-md bg-slate-200 px-3 py-1 text-xs font-bold text-slate-700 border border-slate-300/30">
                  Storefront Role
                </div>
                <h3 className="font-display font-extrabold text-xl text-slate-900">
                  Your only responsibilities:
                </h3>

                <ul className="space-y-4.5 mt-6">
                  <li className="flex items-start gap-3">
                    <div className="mt-1 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-md bg-slate-200 text-slate-700 text-[10px] font-bold font-mono">
                      1
                    </div>
                    <span className="text-xs md:text-sm text-slate-600">
                      <strong>Provide spare floor or counter space:</strong> Assign a small area (typically 2-8 square feet) to store package collections.
                    </span>
                  </li>

                  <li className="flex items-start gap-3">
                    <div className="mt-1 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-md bg-slate-200 text-slate-700 text-[10px] font-bold font-mono">
                      2
                    </div>
                    <span className="text-xs md:text-sm text-slate-600">
                      <strong>Receive weekly deposits:</strong> Amazon deposits funds directly into your business bank account weekly. We take 40% of Net Revenue via Invoice or Wire Transfer.
                    </span>
                  </li>

                  <li className="flex items-start gap-3 border-t border-slate-200 pt-4">
                    <span className="text-xs font-semibold text-amazon-gold font-sans">✓ No complex technical systems on your end. Just continuous local foot traffic and reliable weekly payout checks.</span>
                  </li>
                </ul>
              </div>


            </div>

          </div>

        </div>
      </section>

      {/* 5.5 ALEX HORMOZI'S GRAND SLAM VALUE STACK (CLICKFUNNELS & WHOP LUXURY UX) */}
      <section className="py-20 md:py-28 bg-slate-950 text-white relative overflow-hidden border-t border-slate-800">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_30%,rgba(217,119,6,0.06),transparent_60%)] pointer-events-none" />
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative">
          
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12">
            <span className="text-xs font-bold text-amber-500 uppercase tracking-widest bg-amber-500/10 px-3.5 py-1.5 rounded-md border border-amber-500/20 font-mono">
              ★ Fully Managed Integration ★
            </span>
            <h2 className="font-display text-4xl font-extrabold tracking-tight text-white leading-tight">
              A Direct Partnership Built for Storefront Growth
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              We eliminate the setup friction, administrative workload, and technical overhead. Our team succeeds only when your storefront earns.
            </p>
          </div>

          <div className="max-w-4xl mx-auto space-y-4">
            
            {/* Value Item 1 */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-md p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-amber-500/20 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-amber-500/10 text-amazon-gold border border-amber-500/20">
                  <FileBadge className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-display font-bold text-base text-white flex items-center gap-2">
                    Application Processing
                    <span className="text-[10px] font-semibold text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded">Included</span>
                  </h4>
                  <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed">
                    We coordinate your corporate registration and direct compliance checks with Amazon Logistics.
                  </p>
                </div>
              </div>
              <div className="shrink-0 text-right sm:border-l border-slate-800 sm:pl-6">
                <span className="text-xs text-slate-500 line-through font-mono block">$1,500 Value</span>
                <span className="text-sm font-bold text-amber-500 font-mono block">FREE</span>
              </div>
            </div>

            {/* Value Item 2 */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-md p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-amber-500/20 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-amber-500/10 text-amazon-gold border border-amber-500/20">
                  <Users className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-display font-bold text-base text-white flex items-center gap-2">
                    Courier Management & Recruiting
                    <span className="text-[10px] font-semibold text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded">Included</span>
                  </h4>
                  <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed">
                    We employ and coordinate local logistics couriers to keep your storefront's incoming parcel flow running.
                  </p>
                </div>
              </div>
              <div className="shrink-0 text-right sm:border-l border-slate-800 sm:pl-6">
                <span className="text-xs text-slate-500 line-through font-mono block">$3,200 Value</span>
                <span className="text-sm font-bold text-amber-500 font-mono block">FREE</span>
              </div>
            </div>

            {/* Value Item 3 */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-md p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-amber-500/20 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-amber-500/10 text-amazon-gold border border-amber-500/20">
                  <MapPin className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="font-display font-bold text-base text-white flex items-center gap-2">
                    Logistics Routing Software
                    <span className="text-[10px] font-semibold text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded">Included</span>
                  </h4>
                  <p className="text-slate-400 text-xs sm:text-sm mt-1 leading-relaxed">
                    Continuous route status sync and delivery drop calculations are fully optimized by our direct technical tools.
                  </p>
                </div>
              </div>
              <div className="shrink-0 text-right sm:border-l border-slate-800 sm:pl-6">
                <span className="text-xs text-slate-500 line-through font-mono block">$1,800 Value</span>
                <span className="text-sm font-bold text-amber-500 font-mono block">FREE</span>
              </div>
            </div>

            {/* Done-for-You Summary Block */}
            <div className="bg-slate-900 border-2 border-amber-500/30 rounded-md p-6 md:p-8 space-y-6 mt-8 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/5 rounded-md filter blur-2xl pointer-events-none" />
              <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-6">
                <div className="space-y-2">
                  <span className="text-xs text-amber-500 font-mono uppercase tracking-widest font-extrabold block">✓ Risk-Free Partnership Models</span>
                  <p className="text-lg md:text-xl font-extrabold text-white font-display">
                    Fully Outsourced Operations Management
                  </p>
                  <p className="text-slate-450 text-xs leading-relaxed max-w-xl text-slate-400">
                    Because we work strictly on a performance-based alignment, we absorb 100% of the operational risk and administrative setup costs. If your store doesn't make money, we draw $0.
                  </p>
                </div>
                <div className="bg-slate-950 p-6 rounded-md border border-slate-800 text-center flex flex-col justify-center min-w-[210px] shrink-0 font-sans font-sans">
                  <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold font-mono">Upfront Setup Cost</span>
                  <span className="text-4xl font-extrabold text-emerald-400 font-mono tracking-tight mt-1">$0.00</span>
                  <span className="text-[10px] text-slate-400 mt-1 font-mono font-medium">100% Zero Upfront Risk</span>
                </div>
              </div>

              <div className="h-[1px] bg-slate-800" />
              
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                <p className="text-xs text-slate-400 max-w-lg leading-relaxed font-sans font-sans">
                  "Most programmatic setup services require expensive retainer fees. This team bypassed all of that and handles everything for a direct, simple partnership split."
                </p>
                <button
                  onClick={() => handleOpenBooking()}
                  className="rounded-md bg-amazon-gold hover:bg-amazon-gold-hover text-amazon-ink font-bold py-3.5 px-6 text-xs md:text-sm tracking-wide transition shadow-lg shrink-0 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  Verify My Store Eligibility Now
                </button>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 6. REVENUE BREAKDOWN */}
      <RevenueSection onOpenBooking={() => handleOpenBooking()} />

      {/* 7. REAL-WORLD BENEFITS COMPILATION */}
      <section className="py-16 md:py-24 bg-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-3xl mx-auto space-y-3 mb-12 md:mb-16">
            <span className="text-xs font-bold text-amazon-gold uppercase tracking-widest bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200">
              Benefits of the Program
            </span>
            <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900">
              Why storefronts partner with us
            </h2>
            <p className="text-slate-500 text-sm sm:text-base">
              Here is why physical retailers choose to secure their local zip code allotments:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            
            <div className="space-y-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-200/60 font-bold text-sm">✓</div>
              <h4 className="font-display font-bold text-base text-slate-900">Zero Staff Overhead</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                We handle the setup. Your staff doesn't have to scan incoming parcels or manage complex registries.
              </p>
            </div>

            <div className="space-y-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-200/60 font-bold text-sm">✓</div>
              <h4 className="font-display font-bold text-base text-slate-900">Minimal Floor Space</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                We match the installation to your layout. It can sit neatly behind a counter desk or by an empty lobby wall.
              </p>
            </div>

            <div className="space-y-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-200/60 font-bold text-sm">✓</div>
              <h4 className="font-display font-bold text-base text-slate-900">Consistent Foot Traffic</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Brings high-intent neighborhood buyers directly to your business, increasing incremental sales on everyday items.
              </p>
            </div>

            <div className="space-y-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-200/60 font-bold text-sm">✓</div>
              <h4 className="font-display font-bold text-base text-slate-900">Community Landmark</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Having an official local Amazon Hub makes your storefront a convenient, secure node in your community.
              </p>
            </div>

            <div className="space-y-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-200/60 font-bold text-sm">✓</div>
              <h4 className="font-display font-bold text-base text-slate-900">Weekly Payout Structure</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Enjoy reliable, weekly direct deposits paid by Amazon directly into your business bank account.
              </p>
            </div>

            <div className="space-y-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-200/60 font-bold text-sm">✓</div>
              <h4 className="font-display font-bold text-base text-slate-900">Zero Inventory Headache</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                No stock purchase risk, aging margin concerns, or wholesale invoices. Amazon delivers packages pre-allocated and insured.
              </p>
            </div>

            <div className="space-y-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-200/60 font-bold text-sm">✓</div>
              <h4 className="font-display font-bold text-base text-slate-900">Protected Territories</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                We protect your area's allotment to make sure other nearby stores don't dilute your local package flows.
              </p>
            </div>

            <div className="space-y-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-200/60 font-bold text-sm">✓</div>
              <h4 className="font-display font-bold text-base text-slate-900">No Complex Contracts</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                We believe in flexible partnerships. If your store undergoes any changes, you can cancel easily with simple notice.
              </p>
            </div>

          </div>

        </div>
      </section>

      {/* 8. MOTIVATIONAL EARNING SCENARIOS */}
      <section className="py-16 md:py-20 bg-slate-950 text-white relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-radial from-slate-900 to-slate-950 rounded-md p-8 md:p-12 border border-slate-800">
            
            <div className="lg:col-span-8 space-y-4">
              <span className="text-amazon-gold font-mono text-xs font-bold tracking-widest uppercase block">
                ★ A Simple Monthly Example
              </span>
              <h3 className="font-display text-2xl sm:text-3xl font-extrabold tracking-tight">
                Typical Store Profit Breakdown Scenario
              </h3>
              <p className="text-slate-350 text-sm leading-relaxed max-w-2xl">
                Let's look at a typical independent retail store or pharmacy with steady daily traffic participating in the Amazon Hub program:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
                <div className="bg-slate-900/80 p-4 rounded-md border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold block">Total Monthly Revenue:</span>
                  <strong className="font-mono text-lg text-white font-black">$2,000 / month</strong>
                </div>
                <div className="bg-amazon-ink-light p-4 rounded-md border border-amazon-gold/20">
                  <span className="text-[10px] text-amazon-gold uppercase tracking-wider font-bold block">Your Keepable Share (60%):</span>
                  <strong className="font-mono text-lg text-amazon-gold font-black">$1,200 / month</strong>
                </div>
                <div className="bg-slate-900/85 p-4 rounded-md border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold block">Our Management Share (40%):</span>
                  <strong className="font-mono text-lg text-slate-400 font-black">$800 (40%)</strong>
                </div>
              </div>

              <div className="bg-slate-900 p-4 rounded-md border border-slate-800 flex items-center gap-3 max-w-2xl mt-4">
                <div className="text-amazon-gold font-bold self-start">✓</div>
                <p className="text-xs text-slate-350">
                  <strong>Outcome:</strong> Your store generates an extra <strong>$14,400 / year</strong> with zero extra work. Many owners use this reliable cash flow to help cover their monthly commercial utilities or tax costs.
                </p>
              </div>
            </div>

            <div className="lg:col-span-4 flex flex-col items-center justify-center p-6 bg-slate-900/50 rounded-md border border-slate-800 text-center">
              <span className="text-[11px] text-slate-400 font-mono tracking-widest uppercase">Consultation Strategy</span>
              <h4 className="font-display font-extrabold text-amber-500 text-xl mt-1 leading-tight">
                Check Zip Code Availability
              </h4>
              <p className="text-xs text-slate-300 mt-2 max-w-xs">
                Booking a conversation to review your zip code and physical layout options is 100% free.
              </p>
              <button
                id="scenario-cta-btn"
                onClick={() => handleOpenBooking()}
                className="w-full mt-5 rounded-lg bg-amazon-gold hover:bg-amazon-gold-hover text-amazon-ink font-extrabold py-3 text-xs transition cursor-pointer shadow-md shadow-amber-500/10"
              >
                Check Local Space & Availability
              </button>
            </div>

          </div>

        </div>
      </section>

      {/* 9. TRUST & COMPLIANCE SECTOR */}
      <section id="social-proof" className="py-16 md:py-24 bg-white scroll-mt-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          
          {/* Compliance banner list */}
          <div className="rounded-md bg-slate-50 p-6 md:p-10 border border-slate-200">
            <h4 className="font-display font-bold text-center text-slate-900 mb-6 uppercase tracking-wider text-xs">
              ✦ Our Consulting Assurances ✦
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
              <div className="space-y-1.5 md:border-r border-slate-200 md:pr-6">
                <span className="text-amazon-gold font-mono text-xs font-bold block">01 // RELIABILITY FOCUS</span>
                <p className="text-sm font-bold text-slate-900 leading-snug">A Dedicated Delivery Fit</p>
                <p className="text-xs text-slate-500">All setups comply with official guidelines, keeping your store workspace fully organized and risk-free.</p>
              </div>
              <div className="space-y-1.5 md:border-r border-slate-200 md:px-6">
                <span className="text-amazon-gold font-mono text-xs font-bold block">02 // TRANSPARENT PAYOUTS</span>
                <p className="text-sm font-bold text-slate-900 leading-snug">Direct & Steady Deposits</p>
                <p className="text-xs text-slate-500">Your 60% revenue share is calculated clearly and paid directly into your business bank account on the 10th of every month.</p>
              </div>
              <div className="space-y-1.5 md:pl-6">
                <span className="text-amazon-gold font-mono text-xs font-bold block">03 // VETTED PROCESS</span>
                <p className="text-sm font-bold text-slate-900 leading-snug">Complete Onboarding</p>
                <p className="text-xs text-slate-500">We steer your storefront through the standard verification, route coordinates, and physical setup as smoothly as possible.</p>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* 10. FAQS SECTION (ACCORDION SECTOR) */}
      <FaqSection />

      {/* 12. FINAL CTA SECTION (URGENCY BOX) */}
      <section className="py-24 bg-slate-900 border-t border-slate-800 text-white relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-1/2 translate-x-1/2 w-[800px] h-[400px] bg-amber-500/5 rounded-md blur-2xl pointer-events-none" />

        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 text-center space-y-12 relative z-10">
          
          <div className="max-w-3xl mx-auto space-y-4">
            <div className="inline-flex rounded-md bg-amazon-gold/10 text-amazon-gold border border-amazon-gold/20 px-3 py-1.5 text-[10px] sm:text-xs font-bold tracking-widest font-mono uppercase">
              BOSTON STORE-FRONT BUSINESSES:
            </div>
            <h2 className="font-display text-4xl sm:text-5xl md:text-6xl font-extrabold text-white tracking-tight leading-tight">
              Monetize Your Extra Retail Space
            </h2>
            <p className="text-slate-400 text-base sm:text-lg max-w-2xl mx-auto leading-relaxed">
              If you've got unused retail capacity, there's a proven way to turn it into income without the operational headache. Learn how our partnership model works and what's realistic for your location.
            </p>
          </div>

          <div className="rounded-md bg-slate-900/50 backdrop-blur-md border border-slate-700/50 p-8 md:p-12 max-w-3xl mx-auto shadow-2xl relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-white/[0.03] to-transparent pointer-events-none" />
            <div className="relative z-10 space-y-8">
              <h3 className="font-display font-bold text-xl sm:text-2xl text-white">
                Start Your Passive Income Journey Today
              </h3>
              
              <div className="flex flex-col sm:flex-row items-stretch justify-center gap-4 max-w-lg mx-auto">
                <button
                  id="final-cta-btn"
                  onClick={() => handleOpenBooking()}
                  className="flex-1 rounded-md bg-amazon-gold hover:bg-amazon-gold-hover active:scale-[0.99] text-amazon-ink font-extrabold py-4 px-8 text-sm transition shadow-lg shadow-amber-500/10 cursor-pointer flex items-center justify-center gap-2"
                >
                  <span>Check Store Eligibility</span>
                  <ArrowRight className="h-4 w-4" />
                </button>
                
                <a 
                  href="tel:18005552696" 
                  className="flex-1 rounded-md border border-slate-700 bg-slate-800 hover:bg-slate-700 text-white font-bold py-4 px-6 text-sm transition flex items-center justify-center gap-2"
                >
                  <Phone className="h-4 w-4 text-amazon-gold" />
                  Call 1-800-555-AMZN
                </a>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-4 text-[11px] text-slate-400 font-medium">
                <span className="flex items-center gap-1.5 font-sans"><ShieldCheck className="h-4 w-4 text-amazon-gold" /> Full Spatial Routing Audit Available</span>
                <span className="flex items-center gap-1.5 font-sans"><ShieldCheck className="h-4 w-4 text-amazon-gold" /> Risk-Free Partnership Model</span>
                <span className="flex items-center gap-1.5 font-sans"><ShieldCheck className="h-4 w-4 text-amazon-gold" /> Guaranteed Route Compliance</span>
              </div>
            </div>
          </div>
          
        </div>
      </section>

      {/* FOOTER */}
      <Footer />

      {/* Booking Form modal component trigger */}
      <BookingModal 
        isOpen={isBookingOpen} 
        onClose={() => setIsBookingOpen(false)} 
        initialStoreType={initialStoreType}
        initialLocations={initialLocations}
      />

    </div>
  );
}
