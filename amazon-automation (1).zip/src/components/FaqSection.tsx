import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

export const FAQS = [
  {
    question: "Will this disrupt my regular retail operations or distract staff?",
    answer: "No. We handle 100% of the program coordination, systems auditing, and integration. Your cashiers of record do not need to register parcel codes or manage complex returns on your storefront computer system.",
    category: "Operations"
  },
  {
    question: "How much square footage does my store need to allocate?",
    answer: "Typically 2 to 8 square feet of shelf or back-counter storage space. No bulky hardware locker units or metal gates are required. We review your layout design during our initial spatial call.",
    category: "Space"
  },
  {
    question: "Do our retail employees need special training?",
    answer: "No training is required. Amazon's regional couriers dropping parcels manage standard scanning, and customers check out automatically. We manage backend logistics remotely.",
    category: "Technology"
  },
  {
    question: "Can we install this across multiple chain locations?",
    answer: "Yes. If you operate regional grocery stores, convenience chains, or multiple pharmacies, we map delivery routing across your entire zip-code portfolio with unified reports.",
    category: "Scaling"
  },
  {
    question: "Does package hosting bring in extra walk-in store sales?",
    answer: "Yes. Around 12% to 18% of Amazon pickup guests complete incremental in-store impulse buys (beverages, daily snacks, paper items) during their retail collection visit.",
    category: "Marketing"
  },
  {
    question: "How fast do direct deposits set up and deploy?",
    answer: "Onboarding—including location vetting, compliance application filing, transit route matching, and logistics approval—takes between 30 and 45 days.",
    category: "Timeline"
  },
  {
    question: "Are there any hidden costs or management retainer fees?",
    answer: "None. We charge zero upfront fees. Our agency absorbs integration, mapping, and compliance costs. We only receive a 40% management fee based on actual weekly payout performance.",
    category: "Pricing"
  }
];

export default function FaqSection() {
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);

  return (
    <section id="faq-section" className="py-16 md:py-24 bg-slate-50 border-t border-b border-slate-100 scroll-mt-16">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        
        <div className="text-center space-y-3 mb-12">
          <span className="text-xs font-bold text-amazon-gold uppercase tracking-widest bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200">
            Common Questions
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Frequently Asked Storeowner Questions
          </h2>
          <p className="text-slate-500 text-sm">
            A transparent look at how our consulting team coordinates and manages your storefront program.
          </p>
        </div>

        <div className="space-y-3.5">
          {FAQS.map((item, idx) => {
            const isExpanded = expandedFAQ === idx;
            return (
              <div 
                key={idx}
                className="rounded-md border border-slate-200 bg-white overflow-hidden shadow-xs transition duration-200"
              >
                <button
                  onClick={() => setExpandedFAQ(isExpanded ? null : idx)}
                  className="w-full flex items-center justify-between p-5 text-left font-sans font-bold text-sm md:text-base text-slate-900 bg-white hover:bg-slate-50/50 transition cursor-pointer"
                >
                  <span>{item.question}</span>
                  <ChevronDown 
                    className={`h-4.5 w-4.5 text-slate-500 shrink-0 transition-transform duration-300 ${
                      isExpanded ? 'rotate-180 text-amazon-gold' : ''
                    }`} 
                  />
                </button>
                
                <div 
                  className={`transition-all duration-300 ease-in-out ${
                    isExpanded ? 'max-h-72 border-t border-slate-100 p-5 bg-slate-50/50' : 'max-h-0 opacity-0 overflow-hidden'
                  }`}
                >
                  <p className="text-xs md:text-sm text-slate-600 leading-relaxed font-sans font-light">
                    {item.answer}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
