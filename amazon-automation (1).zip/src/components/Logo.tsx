import React from 'react';

interface LogoProps {
  layout?: 'horizontal' | 'vertical';
  variant?: 'light' | 'dark';
  iconSize?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export default function Logo({
  layout = 'horizontal',
  variant = 'dark',
  iconSize = 'md',
  className = '',
}: LogoProps) {
  // Determine text and icon sizes based on props
  const iconDimensions = {
    sm: 'h-7 w-7',
    md: 'h-10 w-10',
    lg: 'h-16 w-16',
    xl: 'h-24 w-24',
  }[iconSize];

  const textThemeColors = variant === 'dark' 
    ? { brand: 'text-slate-900', sub: 'text-slate-500' } 
    : { brand: 'text-white', sub: 'text-slate-400' };

  return (
    <div className={`flex ${layout === 'horizontal' ? 'flex-row items-center gap-2.5' : 'flex-col items-center text-center gap-3'} ${className}`}>
      {/* Handcrafted precise crisp SVG reproducing the arrow/loop A+B Brand icon */}
      <svg 
        viewBox="0 0 200 200" 
        className={`${iconDimensions} shrink-0`} 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Left slanted pillar of the "A" */}
        <path 
          d="M75 160 L102 96 L116 102 L89 166 Z" 
          fill="#ff9900" 
        />
        
        {/* Arrow head on top of the 'A' pillar pointing up-right */}
        <path 
          d="M90 73 L116 48 L124 76 L113 72 L90 73 Z" 
          fill="#ff9900" 
        />
        <path 
          d="M102 96 L116 71 L126 77 L112 102 Z" 
          fill="#ff9900" 
        />

        {/* Swooping bar / loop forming the 'B' style connector on the right */}
        {/* Starts on the left side of A, swoops down under, crosses A, loops up on the right and curves back down like a heart */}
        <path 
          d="M71 115 C90 135, 120 115, 142 100 C155 90, 168 100, 162 115 C156 128, 142 142, 128 120 C125 115, 118 118, 122 125 C138 152, 165 142, 172 122 C182 98, 155 75, 134 92 C115 108, 92 122, 76 107 Z" 
          fill="#ff9900" 
        />

        {/* Small hub/node inside the loop curve */}
        <circle cx="152" cy="116" r="3.5" fill="white" />
        <circle cx="152" cy="116" r="1.5" fill="#ff9900" />
      </svg>

      {/* Brand Text styling */}
      <div className={layout === 'horizontal' ? 'text-left' : 'text-center'}>
        <span className={`font-sans font-extrabold tracking-tight block leading-none ${textThemeColors.brand} ${
          layout === 'horizontal' 
            ? iconSize === 'sm' ? 'text-sm' : 'text-xl'
            : iconSize === 'xl' ? 'text-4xl' : 'text-2xl'
        }`}>
          amazon
        </span>
        <span className={`font-sans font-bold uppercase tracking-[0.25em] block ${textThemeColors.sub} ${
          layout === 'horizontal'
            ? 'text-[8px] leading-3 mt-0.5'
            : 'text-xs mt-1'
        }`}>
          automation
        </span>
      </div>
    </div>
  );
}
