import React, { useState } from 'react';
import { X, CheckCircle, Phone, Calendar, Clock, MapPin, Sparkles, Building2 } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialStoreType?: string;
  initialLocations?: number;
}

export default function BookingModal({ isOpen, onClose, initialStoreType = 'convenience', initialLocations = 1 }: BookingModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    businessName: '',
    storeType: initialStoreType,
    phoneNumber: '',
    email: '',
    locationsCount: initialLocations,
    availableSpace: '4-8',
    additionalInfo: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate real API submission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 1200);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-xs">
      <div 
        id="booking-modal-container"
        className="relative w-full max-w-2xl overflow-hidden rounded-md bg-white shadow-2xl transition-all duration-300 transform scale-100 flex flex-col md:flex-row max-h-[90vh]"
      >
        {/* Close Button */}
        <button 
          id="close-modal-btn"
          onClick={onClose}
          className="absolute top-4 right-4 z-10 rounded-md p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-600 transition"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Success Screen */}
        {isSuccess ? (
          <div className="w-full p-8 md:p-12 text-center flex flex-col items-center justify-center bg-slate-50">
            <div className="mb-6 rounded-md bg-amber-50 p-4 text-amazon-gold border border-amber-100">
              <CheckCircle className="h-12 w-12 animate-bounce" />
            </div>
            <h3 className="font-display text-2xl font-bold text-slate-900 mb-3">
              Consultation Scheduled!
            </h3>
            <p className="text-slate-600 max-w-md mx-auto mb-6">
              Thank you, <strong className="text-slate-800">{formData.name}</strong>. We've received your request for <strong className="text-slate-800">{formData.businessName}</strong> and are reviewing delivery counts in your zip code right now.
            </p>

            <div className="w-full max-w-md rounded-md bg-white p-6 shadow-sm border border-slate-100 text-left mb-6">
              <h4 className="font-medium text-slate-800 mb-3 flex items-center gap-2">
                <Clock className="h-4 w-4 text-amazon-gold" /> Here's what's next:
              </h4>
              <ul className="space-y-3.5 text-sm text-slate-600">
                <li className="flex items-start gap-2.5">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-105 border-amber-200 text-xs font-semibold">1</span>
                  <span><strong>Area Capacity Review:</strong> We check the package volumes and regional delivery routes in your local zip code.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-105 border-amber-200 text-xs font-semibold">2</span>
                  <span><strong>Introduction Call:</strong> One of our logistics specialists will call you at <strong className="text-amazon-ink font-semibold">{formData.phoneNumber}</strong> within the next business day.</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-amber-50 text-amazon-gold border border-amber-105 border-amber-200 text-xs font-semibold">3</span>
                  <span><strong>Custom Proposal:</strong> We will share a simple plan showing exactly how the setup fits and your estimated monthly revenue.</span>
                </li>
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full max-w-md">
              <a 
                href="tel:18005552696" 
                className="flex items-center justify-center gap-2 w-full rounded-md bg-amazon-ink px-5 py-3 text-sm font-semibold text-white hover:bg-amazon-ink-light transition shadow-md"
              >
                <Phone className="h-4 w-4 text-amazon-gold" />
                Call Agent Directly
              </a>
              <button 
                onClick={onClose}
                className="w-full rounded-md border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-600 hover:bg-slate-50 transition"
              >
                Close Window
              </button>
            </div>
            
            <p className="text-xs text-slate-400 mt-6 font-mono">
              Confirmation ID: AMZ-{Math.floor(100000 + Math.random() * 900000)}
            </p>
          </div>
        ) : (
          <>
            {/* Left Column Strategy Pitch */}
            <div className="hidden md:flex flex-col justify-between w-[240px] shrink-0 bg-amazon-ink text-white p-6 relative">
              <div className="space-y-6">
                <div>
                  <h4 className="font-display font-bold text-lg text-white mb-2 leading-snug">
                    Steady, Passive Store Revenue
                  </h4>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    Convert underutilized storefront or desk space into consistent recurring earnings.
                  </p>
                </div>

                <div className="space-y-3 pt-4 border-t border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle className="h-4 w-4 text-amazon-gold shrink-0" />
                    <span className="text-xs text-slate-200">No extra staffing required</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <CheckCircle className="h-4 w-4 text-amazon-gold shrink-0" />
                    <span className="text-xs text-slate-200">Managed design & setup</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <CheckCircle className="h-4 w-4 text-amazon-gold shrink-0" />
                    <span className="text-xs text-slate-200">Risk-free partnership model</span>
                  </div>
                </div>
              </div>

              <div className="text-xs text-slate-400 pt-6">
                <p className="font-mono">★ Setup & Logistics Specialists</p>
              </div>
            </div>

            {/* Right Column Booking Form */}
            <div className="flex-1 p-6 md:p-8 overflow-y-auto">
              <div className="mb-4">
                <div className="inline-flex items-center gap-1.5 rounded-md bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amazon-gold border border-amber-200">
                  <Calendar className="h-3.5 w-3.5" /> Free Consultation Call
                </div>
                <h3 className="font-display text-xl font-bold text-slate-900 mt-2">
                  Check Space & Area Availability
                </h3>
                <p className="text-slate-500 text-xs mt-1">
                  Amazon assigns Hub Delivery partnerships strictly by location density and package frequency, so we check local availability to guarantee your zip code is open.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Your Full Name *
                    </label>
                    <input 
                      type="text" 
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      placeholder="Nathaniel Turok" 
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-amazon-gold focus:bg-white focus:ring-1 focus:ring-amazon-gold outline-none transition"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Business Name *
                    </label>
                    <input 
                      type="text" 
                      name="businessName"
                      required
                      value={formData.businessName}
                      onChange={handleInputChange}
                      placeholder="e.g. Apex Corner Pharmacy" 
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-amazon-gold focus:bg-white focus:ring-1 focus:ring-amazon-gold outline-none transition"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Business Location Type
                    </label>
                    <select 
                      name="storeType"
                      value={formData.storeType}
                      onChange={handleInputChange}
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-amazon-gold focus:bg-white focus:ring-1 focus:ring-amazon-gold outline-none transition"
                    >
                      <option value="convenience">Convenience Store</option>
                      <option value="pharmacy">Independent Pharmacy</option>
                      <option value="boutique">Retail Boutique / Shop</option>
                      <option value="gift_shop">Gift / Specialty Store</option>
                      <option value="other_retail">Other Commercial Location</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Number of Locations
                    </label>
                    <input 
                      type="number" 
                      name="locationsCount"
                      min={1}
                      max={50}
                      value={formData.locationsCount}
                      onChange={handleInputChange}
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-amazon-gold focus:bg-white focus:ring-1 focus:ring-amazon-gold outline-none transition"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Your Direct Phone *
                    </label>
                    <input 
                      type="tel" 
                      name="phoneNumber"
                      required
                      value={formData.phoneNumber}
                      onChange={handleInputChange}
                      placeholder="(555) 000-0000" 
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-amazon-gold focus:bg-white focus:ring-1 focus:ring-amazon-gold outline-none transition"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Contact Email *
                    </label>
                    <input 
                      type="email" 
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="you@domain.com" 
                      className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-amazon-gold focus:bg-white focus:ring-1 focus:ring-amazon-gold outline-none transition"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Available Counter or Floor Space (approx)
                  </label>
                  <select 
                    name="availableSpace"
                    value={formData.availableSpace}
                    onChange={handleInputChange}
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-amazon-gold focus:bg-white focus:ring-1 focus:ring-amazon-gold outline-none transition"
                  >
                    <option value="2-4">2 - 4 sq. ft. (Small Drawer / Back-Counter Holding)</option>
                    <option value="4-8">4 - 8 sq. ft. (Counter-end package holding area)</option>
                    <option value="8-15">8 - 15 sq. ft. (Dedicated shelf or backroom corner)</option>
                    <option value="15+">15+ sq. ft. (Spacious backroom or secure receiving area)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Store Address or Specific Notes (Optional)
                  </label>
                  <textarea 
                    name="additionalInfo"
                    rows={2}
                    value={formData.additionalInfo}
                    onChange={handleInputChange}
                    placeholder="Provide your address, zip code, or specific hours of operations to expedite eligibility evaluation."
                    className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 focus:border-amazon-gold focus:bg-white focus:ring-1 focus:ring-amazon-gold outline-none transition resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center gap-2 rounded-md bg-amazon-gold hover:bg-amazon-gold-hover active:scale-[0.99] text-amazon-ink font-bold px-6 py-3 font-semibold text-sm transition shadow-md hover:shadow-lg disabled:opacity-50 mt-2 cursor-pointer"
                >
                  {isSubmitting ? (
                    <>
                      <div className="h-4 w-4 animate-spin rounded-md border-2 border-white border-t-transparent" />
                      Checking local space...
                    </>
                  ) : (
                    <>
                      <Building2 className="h-4 w-4" />
                      Schedule Your Free Consultation
                    </>
                  )}
                </button>
              </form>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
