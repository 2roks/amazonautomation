import React from 'react';
import Logo from './Logo';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-b border-slate-800 pb-8">
          <Logo layout="horizontal" variant="light" iconSize="sm" />
          
          <p className="text-[11px] text-slate-500 max-w-md text-center md:text-right font-light">
            We are an independent space utilization and consulting agency. We help local brick-and-mortar stores connect with standard corporate fulfillment programs to create new revenue streams.
          </p>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-8 text-[11px]">
          <p className="text-slate-500">
            &copy; {new Date().getFullYear()} Amazon Automation. All Rights Reserved.
          </p>
          
          <div className="flex gap-4 text-slate-500 font-medium">
            <a href="#" className="hover:underline hover:text-white">On-Site Security Terms</a>
            <a href="#" className="hover:underline hover:text-white font-mono">100% Secure Wire SLA</a>
            <a href="#" className="hover:underline hover:text-white">Exit Ordinance Clause</a>
          </div>
        </div>

      </div>
    </footer>
  );
}
