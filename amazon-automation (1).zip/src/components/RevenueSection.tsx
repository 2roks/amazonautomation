import React from 'react';
import { Check } from 'lucide-react';

interface RevenueSectionProps {
  onOpenBooking: () => void;
}

export default function RevenueSection({ onOpenBooking }: RevenueSectionProps) {
  return (
    <section id="revenue-section" className="py-16 md:py-24 bg-slate-50 border-t border-b border-slate-100 relative">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-12">
          <span className="text-xs font-bold text-amazon-gold uppercase tracking-widest bg-amber-50 px-2.5 py-1 rounded-md border border-amber-200">
            Straightforward Returns
          </span>
          <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            A Consistent ~<span className="text-amazon-gold">$24,000/yr</span> Revenue Stream
          </h2>
          <p className="text-slate-500 text-sm leading-relaxed">
            Convert extra space into recurring weekly income averaging $24K annually.
          </p>
        </div>

        <div className="max-w-4xl mx-auto bg-white rounded-md border border-slate-200 shadow-xl shadow-slate-200/40 p-8 md:p-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16 items-center">
            <div className="space-y-8">
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="h-2 w-2 rounded-md bg-amazon-gold"></div>
                  <span className="font-mono text-sm font-bold text-slate-500 uppercase tracking-widest">Average Weekly Deposit</span>
                </div>
                <div className="font-display font-extrabold text-4xl text-slate-900 tracking-tight">$450 - $500</div>
                <p className="text-sm text-slate-500 font-sans">Paid automatically every single week.</p>
              </div>
              
              <div className="h-[1px] bg-slate-100" />
              
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="h-2 w-2 rounded-md bg-slate-800"></div>
                  <span className="font-mono text-sm font-bold text-slate-500 uppercase tracking-widest">Projected Annual Total</span>
                </div>
                <div className="font-display font-extrabold text-5xl text-amazon-gold tracking-tighter">~$24,000</div>
                <p className="text-sm text-slate-500 font-sans">Gross revenue stream. No inventory. No new hires.</p>
              </div>
            </div>
            
            <div className="bg-slate-50 rounded-md p-6 sm:p-8 border border-slate-100 space-y-6">
              <h4 className="font-display font-bold text-lg text-slate-900">How the math works:</h4>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                  <span className="text-sm text-slate-600">Amazon allocates daily package routes based on neighborhood density.</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                  <span className="text-sm text-slate-600">We secure your location's approval to host these daily drops.</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                  <span className="text-sm text-slate-600">You receive a flat payout per package held, averaging ~$460/week for standard storefronts.</span>
                </li>
              </ul>
              <div className="pt-4">
                <button 
                  onClick={onOpenBooking}
                  className="w-full rounded-md bg-amazon-ink hover:bg-slate-800 text-white font-bold py-3.5 px-6 transition text-sm flex items-center justify-center gap-2"
                >
                  Check My Store's Eligibility
                </button>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
