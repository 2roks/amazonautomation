import React from 'react';
import { Phone, Award, Layers } from 'lucide-react';
import Logo from './Logo';

interface NavbarProps {
  onOpenBooking: () => void;
}

export default function Navbar({ onOpenBooking }: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-100 transition-all duration-200">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          {/* Logo element */}
          <Logo layout="horizontal" variant="dark" iconSize="sm" />

          {/* Desktop Links */}
          <nav className="hidden md:flex items-center gap-7 text-[13px] font-semibold text-slate-600">
            <a href="#problem-section" className="hover:text-slate-900 transition font-sans">
              Store Challenges
            </a>
            <a href="#how-it-works" className="hover:text-slate-900 transition font-sans">
              DFY Advantage
            </a>
            <a href="#calculator-section" className="hover:text-slate-900 transition font-sans">
              ROI Simulator
            </a>
            <a href="#social-proof" className="hover:text-slate-900 transition font-sans">
              Real Case Studies
            </a>
            <a href="#faq-section" className="hover:text-slate-900 transition font-sans">
              FAQs
            </a>
          </nav>

          {/* Call to Action and Direct dial */}
          <div className="flex items-center gap-3">
            <a 
              href="tel:18005552696" 
              className="hidden lg:flex items-center gap-2 rounded-md border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-100 transition font-mono"
            >
              <Phone className="h-3.5 w-3.5 text-amazon-gold" />
              1-800-555-AMZN
            </a>

            <button
               id="navbar-cta-btn"
               onClick={onOpenBooking}
               className="rounded-xl bg-amazon-gold hover:bg-amazon-gold-hover active:scale-[0.98] px-4 py-2 text-xs font-bold text-amazon-ink shadow-md transition cursor-pointer"
            >
              Book Store Consultation
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
