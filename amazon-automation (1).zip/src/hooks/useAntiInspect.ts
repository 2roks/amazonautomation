import { useEffect } from 'react';

export function useAntiInspect() {
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent F12
      if (e.key === 'F12') {
        e.preventDefault();
      }
      
      // Prevent Ctrl+Shift+I (Windows) or Cmd+Opt+I (Mac)
      if ((e.ctrlKey && e.shiftKey && e.key === 'I') || (e.metaKey && e.altKey && e.key === 'i')) {
        e.preventDefault();
      }

      // Prevent Ctrl+Shift+J (Windows) or Cmd+Opt+J (Mac)
      if ((e.ctrlKey && e.shiftKey && e.key === 'J') || (e.metaKey && e.altKey && e.key === 'j')) {
        e.preventDefault();
      }

      // Prevent Ctrl+U (Windows) or Cmd+U (Mac) input source viewing
      if ((e.ctrlKey && e.key === 'u') || (e.metaKey && e.key === 'u') || (e.ctrlKey && e.key === 'U') || (e.metaKey && e.key === 'U')) {
        e.preventDefault();
      }
      
      // Prevent Ctrl+Shift+C (Windows) or Cmd+Shift+C (Mac)
      if ((e.ctrlKey && e.shiftKey && e.key === 'C') || (e.metaKey && e.shiftKey && e.key === 'c')) {
        e.preventDefault();
      }
    };

    document.addEventListener('contextmenu', handleContextMenu);
    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);
}
