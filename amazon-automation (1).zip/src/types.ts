export type StoreLocationType = 'convenience' | 'pharmacy' | 'boutique' | 'gift_shop' | 'other_retail';

export interface LocationConfig {
  name: string;
  baseMonthlyRevenue: number; // base package volume revenue
  avgFootTrafficPowerMultiplier: number; // how traffic scales
  label: string;
}

export interface CalculatorState {
  storeType: StoreLocationType;
  footTraffic: number; // average daily visitors
  avgSpaceSqFt: number; // 2 sqft to 20 sqft
  locationsCount: number; // 1 to 20 locations
}

export interface EligibilityAnswer {
  questionId: string;
  value: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export interface LeadForm {
  name: string;
  businessName: string;
  storeType: string;
  phoneNumber: string;
  email: string;
  locationsCount: number;
  availableSpace: string;
  additionalInfo?: string;
}
